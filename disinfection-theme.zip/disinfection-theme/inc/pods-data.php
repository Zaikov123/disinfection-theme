<?php

function disinfection_load_pods_data() {

    $tabs_pod = pods('pest_tabs', [
        'limit' => -1,
        'orderby' => 'menu_order ASC'
    ]);

    $tabs = [];
    $tabs_order = [];

    if ($tabs_pod && $tabs_pod->total() > 0) {
        while ($tabs_pod->fetch()) {
            $id = $tabs_pod->id();
            $tabs[$id] = $tabs_pod->display('post_title');
            $tabs_order[] = $id;
        }
    }

    $pests_pod = pods('pests', [
        'limit' => -1,
        'orderby' => 'post_date ASC',
    ]);

    $grouped_pests = [];

    if ($pests_pod && $pests_pod->total() > 0) {
        while ($pests_pod->fetch()) {
            $tab_relation = $pests_pod->field('pest_tab');
            $tab_id = is_array($tab_relation) ? $tab_relation['ID'] : $tab_relation;

            if (!$tab_id || !isset($tabs[$tab_id])) continue;

            $icon_field = $pests_pod->field('icon');
            $icon_url = is_array($icon_field) ? $icon_field['guid'] : '';

            $grouped_pests[$tab_id][] = [
                'title'          => $pests_pod->display('title'),
                'description'    => html_entity_decode(wp_strip_all_tags($pests_pod->display('description')), ENT_QUOTES, 'UTF-8'),
                'icon'           => $icon_url,
                'order_link'     => $pests_pod->field('order_link') ?: '#',
                'more_info_link' => $pests_pod->field('more_info_link') ?: '#',
            ];
        }
    }

    $default_icon_url = wp_get_attachment_url(76);

    wp_localize_script('pests-data', 'WP_PESTS', [
        'tabs'       => $tabs,
        'tabs_order' => $tabs_order,
        'pests'      => $grouped_pests,
        'default_icon' => $default_icon_url,
    ]);
}
add_action('wp_enqueue_scripts', 'disinfection_load_pods_data', 20);
