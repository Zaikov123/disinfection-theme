<?php

function disinfection_enqueue_assets() {
    wp_enqueue_style('reset', get_template_directory_uri() . '/assets/css/reset.css');
    wp_enqueue_style('maincss', get_template_directory_uri() . '/assets/css/style.css');

    wp_enqueue_script('pests-data', get_template_directory_uri() . '/assets/js/data.js', [], '1.0', true);
    wp_enqueue_script('index', get_template_directory_uri() . '/assets/js/index.js', ['pests-data'], null, true);
}
add_action('wp_enqueue_scripts', 'disinfection_enqueue_assets');
