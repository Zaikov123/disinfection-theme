<?php

function disinfection_enable_module_type($tag, $handle) {
    if (in_array($handle, ['index', 'pests-data'])) {
        return str_replace('<script ', '<script type="module" ', $tag);
    }
    return $tag;
}
add_filter('script_loader_tag', 'disinfection_enable_module_type', 10, 2);
