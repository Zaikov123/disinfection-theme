<?php
show_admin_bar(false);
