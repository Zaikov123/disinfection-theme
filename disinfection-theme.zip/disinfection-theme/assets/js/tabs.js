export function initTabs(tabs, renderTab) {
  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      tabs.forEach((t) => {
        t.classList.remove("button-like--primary");
        t.classList.remove("button-like--secondary");
        t.classList.add("button-like--secondary");
      });
      tab.classList.remove("button-like--secondary");
      tab.classList.add("button-like--primary");
      console.log(tab.dataset.tab);
      renderTab(tab.dataset.tab);
    });
  });
}
