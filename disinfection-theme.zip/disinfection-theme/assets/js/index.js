import { initTabs } from './tabs.js';
import { renderTab, renderTabs } from './renderTabs.js';

document.addEventListener('DOMContentLoaded', () => {
    const tabsContainer = document.querySelector('.content__tabs'); 
    const contentsContainer = document.getElementById('content__tab-contents');

    const firstTabId = renderTabs(tabsContainer);

    if (!firstTabId) {
        contentsContainer.innerHTML = '<p>Вкладки не створено</p>';
        return;
    }

    renderTab(firstTabId, contentsContainer);

    const tabs = document.querySelectorAll('.content__tab');
    initTabs(tabs, (tabId) => renderTab(tabId, contentsContainer));
});