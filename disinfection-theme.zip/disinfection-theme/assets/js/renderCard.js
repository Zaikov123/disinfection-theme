import { DEFAULT_ICON } from "./config.js";

export function renderCard(cardData, toApply) {
  const card = document.createElement("div");
  card.classList.add("content__card");

  const iconSrc = cardData.icon || DEFAULT_ICON;

  if (cardData.icon) {
    const icon = document.createElement("img");
    icon.src = iconSrc;
    icon.alt = cardData.title;
    card.appendChild(icon);
  } else {
    const icon = document.createElement("img");
    icon.src = iconSrc;
    icon.alt = cardData.title || "Default icon";
    card.appendChild(icon);
  }

  const title = document.createElement("h3");
  title.textContent = cardData.title;
  card.appendChild(title);

  const desc = document.createElement("p");
  desc.textContent = cardData.description;
  card.appendChild(desc);

  const buttonGroup = document.createElement("div");
  buttonGroup.classList.add("content__button-group");

  const order = document.createElement("a");
  order.classList.add("button-like", "button-like--primary");
  order.textContent = "Замовити";
  order.href = cardData.order_link || "#";
  order.target =
    cardData.order_link &&
    cardData.order_link !== "#" &&
    !cardData.order_link.startsWith("/")
      ? "_blank"
      : "_self";
  order.rel = order.target === "_blank" ? "noopener" : "";
  buttonGroup.appendChild(order);

  const moreInfo = document.createElement("a");
  moreInfo.classList.add("button-like", "button-like--secondary");
  moreInfo.textContent = "Дізнатись більше";
  moreInfo.href = cardData.more_info_link || "#";
  moreInfo.target =
    cardData.more_info_link &&
    cardData.more_info_link !== "#" &&
    !cardData.more_info_link.startsWith("/")
      ? "_blank"
      : "_self";
  moreInfo.rel = moreInfo.target === "_blank" ? "noopener" : "";
  buttonGroup.appendChild(moreInfo);

  card.appendChild(buttonGroup);

  card.appendChild(buttonGroup);
  toApply.appendChild(card);
}
