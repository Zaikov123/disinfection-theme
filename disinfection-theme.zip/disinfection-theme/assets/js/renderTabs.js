import { tabData, pestTabs } from './data.js';
import { createSlider } from './slider.js';

export function renderTab(tabId, container) {
    const cards = tabData[tabId] || [];
    createSlider(cards, container);
}

export function renderTabs(tabsContainer) {
    tabsContainer.innerHTML = '';

    let firstTabId = null;

    pestTabs.tabs_order.forEach((tabId, index) => {
        const id = tabId.toString();
        const title = pestTabs.tabs[tabId];
        
        const cards = tabData[id];
        if(!cards || cards.length === 0) return;

        if(!firstTabId) firstTabId = id;

        const btn = document.createElement('button');
        btn.className = `content__tab button-like ${index === 0 ? 'button-like--primary' : 'button-like--secondary'}`;
        btn.dataset.tab = id;
        btn.textContent = title;
        tabsContainer.appendChild(btn);
    });

    return firstTabId; 
}