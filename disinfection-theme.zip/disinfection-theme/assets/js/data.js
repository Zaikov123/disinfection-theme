const wp = window.WP_PESTS || {
  tabs: {},
  tabs_order: [],
  pests: {},
  default_icon: "",
};
const tabData = {};
wp.tabs_order.forEach((tabId) => {
  const id = tabId.toString();
  tabData[id] = wp.pests[tabId] || [];
});

export { tabData, wp as pestTabs };
