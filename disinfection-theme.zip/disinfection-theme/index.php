<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Disinfection</title>
    <!-- <link rel="stylesheet" href="./css/reset.css" />
    <link rel="stylesheet" href="./css/style.css" /> -->
    <?php
        wp_head();
    ?>
  </head>
  <body>
    <main class="main">
      <section class="contact">
        <div class="contact__text">
          <h1>
            Професійна<br />
            Дезінфекція по всій Україні
          </h1>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do<br />eiusmod
            tempor incididunt ut labore et dolore magna aliqua.
          </p>
        </div>
        <form class="contact__form">
          <div class="contact__form_el">
            <label for="name">Ваше Ім'я:</label>
            <input
              type="text"
              placeholder="Андрій Остапчук"
              name="name"
              id="name"
              required
            />
          </div>
          <div class="contact__form_el">
            <label for="phone">Номер телефону:</label>
            <input
              type="text"
              placeholder="+(380) 096 258 25 25"
              name="phone"
              id="phone"
              required
            />
          </div>
          <div class="contact__form-el">
            <label for="city">Область(місто):</label>
            <input
              type="text"
              placeholder="Миколаїв"
              name="city"
              id="city"
              required
            />
          </div>
          <div class="contact__form-el">
            <input
              type="submit"
              value="Замовити дзвінок"
              class="button-like button-like--primary"
            />
          </div>
        </form>
      </section>
      <section class="content">
        <h2>Наші послуги</h2>
        <div class="content__tabs">
          <button class="content__tab button-like button-like--primary" data-tab="1">
            Tab 1
          </button>
          <button class="content__tab button-like button-like--secondary" data-tab="2">Tab 2</button>
          <button class="content__tab button-like button-like--secondary" data-tab="3">Tab 3</button>
        </div>

        <div class="content__tab-contents" id="content__tab-contents"></div>
      </section>
    </main>
    <!-- <script type="module"  src="./js/index.js"></script> -->
     <?php
        wp_footer();
     ?>
  </body>
</html>
