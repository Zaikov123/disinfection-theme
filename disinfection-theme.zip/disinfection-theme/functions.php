<?php

require_once get_template_directory() . '/inc/enqueue.php';
require_once get_template_directory() . '/inc/pods-data.php';
require_once get_template_directory() . '/inc/filters.php';
require_once get_template_directory() . '/inc/setup.php';
