<?php
/**
* Template name: Home Page Template
*/
?>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php bloginfo('name'); ?></title>

    <?php
        wp_head();
    ?>
  </head>
  <body>
    <?php while (have_posts()) : the_post(); ?>
      <main class="main">
        <section class="contact">
          <div class="contact__overlay"></div>
            <div class="contact__text">
              <h1><?php the_field('main_title'); ?></h1>
              <p><?php the_field('subtitle'); ?></p>
            </div>
          
          <form class="contact__form">
            <div class="contact__form_el">
              <label for="name">Ваше Ім'я:</label>
              <input
                type="text"
                placeholder="Андрій Остапчук"
                name="name"
                id="name"
                required
              />
            </div>
            <div class="contact__form_el">
              <label for="phone">Номер телефону:</label>
              <input
                type="text"
                placeholder="+(380) 096 258 25 25"
                name="phone"
                id="phone"
                required
              />
            </div>
            <div class="contact__form-el">
              <label for="city">Область(місто):</label>
              <input
                type="text"
                placeholder="Миколаїв"
                name="city"
                id="city"
                required
              />
            </div>
            <div class="contact__form-el">
              <input
                type="submit"
                value="Замовити дзвінок"
                class="button-like button-like--primary"
              />
            </div>
          </form>
        </section>
        <section class="content">
          <h2>Наші послуги</h2>
          <div class="content__tabs"></div>
          <div id="content__tab-contents"></div>

          <div class="content__tab-contents" id="content__tab-contents"></div>
        </section>
      </main>
    <?php endwhile; ?>
     <?php
        wp_footer();
     ?>
  </body>
</html>
