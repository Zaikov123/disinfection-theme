export const DEFAULT_ICON = window.WP_PESTS?.default_icon || '';
export const CHUNK_SIZE = 8;