import { renderCard } from "./renderCard.js";
import { CHUNK_SIZE } from "./config.js";
export function createSlider(tabCards, container) {
  let page = 0;

  const chunks = [];
  for (let i = 0; i < tabCards.length; i += CHUNK_SIZE) {
    chunks.push(tabCards.slice(i, i + CHUNK_SIZE));
  }
  container.innerHTML = "";

  const wrapper = document.createElement("div");
  wrapper.classList.add("content__slider");

  const cardsGrid = document.createElement("div");
  cardsGrid.classList.add("content__cards-grid");

  const nav = document.createElement("div");
  nav.classList.add("content__slider-nav");

  const prevBtn = document.createElement("button");
  prevBtn.classList.add("button-like", "button-like--primary");
  prevBtn.textContent = "←";

  const nextBtn = document.createElement("button");
  nextBtn.classList.add("button-like", "button-like--primary");
  nextBtn.textContent = "→";

  nav.append(prevBtn, nextBtn);
  wrapper.append(cardsGrid, nav);
  container.appendChild(wrapper);

  function renderPage() {
    cardsGrid.innerHTML = "";

    chunks[page].forEach((cardData) => {
      renderCard(cardData, cardsGrid);
    });

    prevBtn.disabled = page === 0;
    nextBtn.disabled = page === chunks.length - 1;
  }

  prevBtn.addEventListener("click", () => {
    if (page > 0) {
      page--;
      renderPage();
    }
  });

  nextBtn.addEventListener("click", () => {
    if (page < chunks.length - 1) {
      page++;
      renderPage();
    }
  });

  renderPage();
}
